module.exports = {
    HOST: 'sauna-king-test.c7v6lqflrx8d.us-east-1.rds.amazonaws.com',
    USER: 'admin',
    PASSWORD: 'Paddlewheeler1',
    DB: 'sauna_king_dev'
};
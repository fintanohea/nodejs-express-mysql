# nodejs-express-mysql
Allow serverless to access our AWS account. Replace ACCESS_KEY and SECRET_KEY above with your AWS access and secret keys.
    - serverless config credentials --provider aws --key ACCESS_KEY ?secret SECRET_KEY

 run [serverless deploy] to deploy to aws 
